#!/usr/bin/env python3
"""Minimal in-memory relay for GhostLink. Run only on a trusted, reachable server."""
from __future__ import annotations

import argparse
import asyncio
import json
import secrets
import time
from dataclasses import dataclass, field

MAX_LINE = 64 * 1024


@dataclass
class Session:
    token: str
    ttl: int
    created: float = field(default_factory=time.monotonic)
    host_writer: asyncio.StreamWriter | None = None
    guest_writer: asyncio.StreamWriter | None = None
    guest_ready: asyncio.Event = field(default_factory=asyncio.Event)
    closed: asyncio.Event = field(default_factory=asyncio.Event)

    @property
    def remaining(self) -> int:
        return max(0, int(self.ttl - (time.monotonic() - self.created)))


class Relay:
    def __init__(self) -> None:
        self.sessions: dict[str, Session] = {}
        self.lock = asyncio.Lock()

    async def reply(self, writer: asyncio.StreamWriter, **data: object) -> None:
        writer.write(json.dumps(data, separators=(",", ":")).encode() + b"\n")
        await writer.drain()

    async def handle(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        session: Session | None = None
        role: str | None = None
        try:
            line = await asyncio.wait_for(reader.readline(), timeout=10)
            if not line or len(line) > MAX_LINE:
                return
            request = json.loads(line.decode("utf-8"))
            action = request.get("action")
            if action == "create":
                ttl = request.get("ttl")
                if not isinstance(ttl, int) or not 60 <= ttl <= 604800:
                    await self.reply(writer, ok=False, error="Duration must be 60–604800 seconds")
                    return
                token = secrets.token_urlsafe(18)
                session = Session(token=token, ttl=ttl, host_writer=writer)
                async with self.lock:
                    self.sessions[token] = session
                role = "host"
                await self.reply(writer, ok=True, token=token, ttl=ttl)
            elif action == "join":
                token = request.get("token")
                async with self.lock:
                    candidate = self.sessions.get(token) if isinstance(token, str) else None
                    if candidate and candidate.remaining > 0 and candidate.guest_writer is None and not candidate.closed.is_set():
                        session = candidate
                        session.guest_writer = writer
                        # Invalidate immediately: the invitation can never be used twice.
                        self.sessions.pop(token, None)
                        role = "guest"
                if session is None:
                    await self.reply(writer, ok=False, error="Invitation is invalid, expired, or already used")
                    return
                await self.reply(writer, ok=True, ttl=session.remaining)
                session.guest_ready.set()
            else:
                await self.reply(writer, ok=False, error="Unknown action")
                return

            assert session is not None and role is not None
            if role == "host":
                try:
                    await asyncio.wait_for(session.guest_ready.wait(), timeout=session.remaining)
                except asyncio.TimeoutError:
                    await self.reply(writer, ok=False, error="Invitation expired before anyone joined")
                    return
                if session.closed.is_set() or session.guest_writer is None:
                    return
                await self.reply(writer, ok=True, paired=True)

            async def expire() -> None:
                await asyncio.sleep(session.remaining)
                session.closed.set()
                for peer in (session.host_writer, session.guest_writer):
                    if peer is not None:
                        peer.close()

            async def pump(src: asyncio.StreamReader, dst: asyncio.StreamWriter) -> None:
                while not session.closed.is_set():
                    data = await src.readline()
                    if not data:
                        break
                    if len(data) > MAX_LINE:
                        break
                    dst.write(data)
                    await dst.drain()

            expiry_task = asyncio.create_task(expire())
            try:
                peer_writer = session.guest_writer if role == "host" else session.host_writer
                if peer_writer is None:
                    return
                # Host and guest each relay only opaque encrypted packets.
                await pump(reader, peer_writer)
            finally:
                session.closed.set()
                for peer in (session.host_writer, session.guest_writer):
                    if peer is not None:
                        peer.close()
                expiry_task.cancel()
                async with self.lock:
                    self.sessions.pop(session.token, None)
        except (json.JSONDecodeError, UnicodeDecodeError, asyncio.TimeoutError, ConnectionError, BrokenPipeError):
            pass
        finally:
            if session is not None and role == "host" and not session.guest_ready.is_set():
                async with self.lock:
                    self.sessions.pop(session.token, None)
            if not writer.is_closing():
                writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass


async def main() -> None:
    parser = argparse.ArgumentParser(description="GhostLink TCP relay (for a reachable server/VPS)")
    parser.add_argument("--host", default="0.0.0.0", help="Bind address (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8765, help="TCP port (default: 8765)")
    args = parser.parse_args()
    relay = Relay()
    server = await asyncio.start_server(relay.handle, args.host, args.port, limit=MAX_LINE + 1)
    sockets = ", ".join(str(sock.getsockname()) for sock in (server.sockets or []))
    print(f"GhostLink relay listening on {sockets}. Press Ctrl+C to stop.")
    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nRelay stopped.")
