#!/usr/bin/env python3
"""GhostLink: lightweight, terminal-based encrypted one-to-one chat client."""
from __future__ import annotations

import argparse
import asyncio
import base64
import json
import os
import sys
import time
from urllib.parse import urlparse

try:
    from nacl.secret import SecretBox
    from nacl.utils import random as random_bytes
except ImportError:
    print("Missing dependency: PyNaCl. Install with: python3 -m pip install --user -r requirements.txt", file=sys.stderr)
    raise SystemExit(2)

MAX_LINE = 64 * 1024
CLEAR_INTERVAL = 50


def b64e(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def b64d(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def encode_packet(box: SecretBox, payload: dict) -> str:
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return b64e(bytes(box.encrypt(raw)))


def decode_packet(box: SecretBox, line: str) -> dict:
    raw = box.decrypt(b64d(line.strip()))
    value = json.loads(raw.decode("utf-8"))
    if not isinstance(value, dict):
        raise ValueError("Invalid message packet")
    return value


async def read_stdin_line(prompt: str) -> str:
    """Read a terminal line without blocking the asyncio network tasks (Unix/Kali)."""
    loop = asyncio.get_running_loop()
    future: asyncio.Future[str] = loop.create_future()
    print(prompt, end="", flush=True)

    def ready() -> None:
        if not future.done():
            future.set_result(sys.stdin.readline())

    loop.add_reader(sys.stdin.fileno(), ready)
    try:
        return await future
    finally:
        loop.remove_reader(sys.stdin.fileno())


async def send_json_line(writer: asyncio.StreamWriter, value: dict) -> None:
    writer.write(json.dumps(value, separators=(",", ":")).encode() + b"\n")
    await writer.drain()


async def read_json_line(reader: asyncio.StreamReader) -> dict:
    line = await reader.readline()
    if not line:
        raise ConnectionError("Relay closed the connection")
    if len(line) > MAX_LINE:
        raise ValueError("Relay response too large")
    value = json.loads(line.decode("utf-8"))
    if not isinstance(value, dict):
        raise ValueError("Invalid relay response")
    return value


def parse_relay(value: str) -> tuple[str, int]:
    if ":" not in value:
        raise argparse.ArgumentTypeError("Relay must be HOST:PORT")
    host, port_text = value.rsplit(":", 1)
    try:
        port = int(port_text)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("Relay port must be a number") from exc
    if not host or not 1 <= port <= 65535:
        raise argparse.ArgumentTypeError("Invalid relay HOST:PORT")
    return host.strip("[]"), port


def parse_invite(invite: str) -> tuple[str, int, str, bytes]:
    parsed = urlparse(invite)
    if parsed.scheme != "ghostlink" or not parsed.hostname or not parsed.port:
        raise ValueError("Invalid invite. Expected ghostlink://HOST:PORT/TOKEN/KEY")
    parts = parsed.path.strip("/").split("/")
    if len(parts) != 2 or not parts[0] or not parts[1]:
        raise ValueError("Invite must contain a token and encryption key")
    key = b64d(parts[1])
    if len(key) != SecretBox.KEY_SIZE:
        raise ValueError("Invite contains an invalid encryption key")
    return parsed.hostname, parsed.port, parts[0], key


async def chat(reader: asyncio.StreamReader, writer: asyncio.StreamWriter, key: bytes, ttl: int) -> None:
    box = SecretBox(key)
    loop = asyncio.get_running_loop()
    finished = asyncio.Event()
    start = time.monotonic()

    print("\nConnected. Messages are encrypted end-to-end. Type /end to close the chat.")
    print("The terminal display clears every 50 seconds; this does not securely erase other copies.\n")

    async def receiver() -> None:
        try:
            while not finished.is_set():
                line = await reader.readline()
                if not line:
                    print("\n[Connection closed by relay]")
                    break
                if len(line) > MAX_LINE:
                    print("\n[Ignored oversized packet]")
                    continue
                try:
                    envelope = json.loads(line.decode("utf-8"))
                    if not isinstance(envelope, dict) or not isinstance(envelope.get("packet"), str):
                        raise ValueError("Invalid envelope")
                    packet = decode_packet(box, envelope["packet"])
                except Exception:
                    print("\n[Ignored invalid or undecryptable packet]")
                    continue
                if packet.get("type") == "end":
                    print("\n[The other person ended the chat]")
                    break
                if packet.get("type") == "message" and isinstance(packet.get("text"), str):
                    stamp = time.strftime("%H:%M:%S")
                    print(f"\n[{stamp}] {packet['text']}")
                    print("> ", end="", flush=True)
        except (ConnectionError, asyncio.CancelledError):
            pass
        finally:
            finished.set()

    async def sender() -> None:
        while not finished.is_set():
            text = await read_stdin_line("> ")
            if text == "":
                finished.set()
                break
            text = text.rstrip("\r\n")
            if text.strip() == "/end":
                await send_json_line(writer, {"packet": encode_packet(box, {"type": "end"})})
                finished.set()
                break
            if text:
                await send_json_line(writer, {"packet": encode_packet(box, {"type": "message", "text": text})})

    async def clear_display() -> None:
        while not finished.is_set():
            await asyncio.sleep(CLEAR_INTERVAL)
            if not finished.is_set():
                # This clears the terminal display only; it is not secure deletion.
                print("\033[2J\033[H", end="", flush=True)
                print("GhostLink — display refreshed. Type /end to close.\n> ", end="", flush=True)

    async def expire() -> None:
        await asyncio.sleep(max(0, ttl - (time.monotonic() - start)))
        if not finished.is_set():
            print("\n[Session timer expired]")
            finished.set()

    tasks = [asyncio.create_task(receiver()), asyncio.create_task(sender()),
             asyncio.create_task(clear_display()), asyncio.create_task(expire())]
    try:
        await finished.wait()
    finally:
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass
        print("\nGhostLink session closed. No chat transcript was written by this client.")


async def host(args: argparse.Namespace) -> None:
    relay_host, relay_port = parse_relay(args.relay)
    ttl = int(args.hours * 3600)
    if ttl < 60 or ttl > 7 * 24 * 3600:
        raise ValueError("Duration must be from 1 minute to 168 hours")
    key = random_bytes(SecretBox.KEY_SIZE)
    reader, writer = await asyncio.open_connection(relay_host, relay_port)
    await send_json_line(writer, {"action": "create", "ttl": ttl})
    response = await read_json_line(reader)
    if not response.get("ok"):
        writer.close()
        raise RuntimeError(response.get("error", "Relay rejected session creation"))
    token = response["token"]
    invite = f"ghostlink://{relay_host}:{relay_port}/{token}/{b64e(key)}"
    print("GhostLink invitation (send privately; anyone holding it can join):\n")
    print(invite + "\n")
    print(f"Session expires in {args.hours:g} hour(s). Invite is single-use. Waiting for the other person…")
    paired = await read_json_line(reader)
    if not paired.get("ok"):
        writer.close()
        raise RuntimeError(paired.get("error", "Pairing failed"))
    await chat(reader, writer, key, ttl)


async def join(args: argparse.Namespace) -> None:
    relay_host, relay_port, token, key = parse_invite(args.invite)
    reader, writer = await asyncio.open_connection(relay_host, relay_port)
    await send_json_line(writer, {"action": "join", "token": token})
    response = await read_json_line(reader)
    if not response.get("ok"):
        writer.close()
        raise RuntimeError(response.get("error", "Could not join session"))
    ttl = int(response.get("ttl", 3600))
    await chat(reader, writer, key, ttl)


def main() -> None:
    parser = argparse.ArgumentParser(prog="ghostlink", description="Small encrypted one-to-one terminal chat")
    sub = parser.add_subparsers(dest="command", required=True)
    host_parser = sub.add_parser("host", help="Create a session and generate a single-use invite")
    host_parser.add_argument("--relay", required=True, help="Relay server as HOST:PORT")
    host_parser.add_argument("--hours", type=float, default=1, help="Session duration in hours (default: 1; max: 168)")
    join_parser = sub.add_parser("join", help="Join using an invitation link")
    join_parser.add_argument("--invite", required=True, help="GhostLink invitation URL")
    args = parser.parse_args()
    try:
        if args.command == "host":
            asyncio.run(host(args))
        else:
            asyncio.run(join(args))
    except KeyboardInterrupt:
        print("\nInterrupted. Closing GhostLink.")
    except (OSError, ValueError, RuntimeError, ConnectionError, asyncio.IncompleteReadError) as exc:
        print(f"GhostLink error: {exc}", file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
