import base64
import unittest

from nacl.secret import SecretBox
from nacl.utils import random

import ghostlink


class PacketTests(unittest.TestCase):
    def test_encrypt_decrypt_roundtrip(self):
        box = SecretBox(random(SecretBox.KEY_SIZE))
        packet = {"type": "message", "text": "hello 🌍"}
        encoded = ghostlink.encode_packet(box, packet)
        self.assertEqual(ghostlink.decode_packet(box, encoded), packet)

    def test_tampering_is_rejected(self):
        box = SecretBox(random(SecretBox.KEY_SIZE))
        encoded = ghostlink.encode_packet(box, {"type": "message", "text": "hello"})
        raw = bytearray(ghostlink.b64d(encoded))
        raw[-1] ^= 1
        altered = ghostlink.b64e(bytes(raw))
        with self.assertRaises(Exception):
            ghostlink.decode_packet(box, altered)

    def test_invite_parser(self):
        key = random(SecretBox.KEY_SIZE)
        invite = f"ghostlink://example.test:8765/abc/{ghostlink.b64e(key)}"
        host, port, token, parsed_key = ghostlink.parse_invite(invite)
        self.assertEqual((host, port, token, parsed_key), ("example.test", 8765, "abc", key))


if __name__ == "__main__":
    unittest.main()
